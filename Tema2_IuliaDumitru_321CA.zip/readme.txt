# TCP-UDP-client-server

Not finished SF, not deactivated Nagle, tried to account for TCP
concatenation/truncation.

Iulia Dumitru, 321CA
